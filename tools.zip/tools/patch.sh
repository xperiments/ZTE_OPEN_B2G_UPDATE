#!/bin/bash
echo "********************************************************"
echo "Copy original boot from sdcard"
echo "********************************************************"
echo ""
adb pull /sdcard/boot.img

echo "********************************************************"
echo "Extract boot.img"
echo "********************************************************"
echo ""
./split_boot boot.img

echo "********************************************************"
echo "Patching default.prop"
echo "********************************************************"
echo ""
cp default.prop boot/ramdisk/default.prop

echo "********************************************************"
echo "Copy utils"
echo "********************************************************"
echo ""
cp repack_ramdisk boot/
cp mkbootimg boot/

cd boot

echo "********************************************************"
echo "Repack Ramdisk"
echo "********************************************************"
echo ""
./repack_ramdisk ramdisk patchedRamDisk.cpio.gz

echo "********************************************************"
echo "Create patched patchedBoot.img"
echo "********************************************************"
echo ""
./mkbootimg --kernel boot.img-kernel --ramdisk patchedRamDisk.cpio.gz --base 0x200000 --cmdline 'androidboot.hardware=roamer2' -o patchedBoot.img

echo "********************************************************"
echo "Push new boot to phone"
echo "********************************************************"
echo ""
adb push patchedBoot.img /sdcard/patchedBoot.img

echo "********************************************************"
echo "Restart phone in CWM recovery mode ( power + volume up )"
echo ""
echo "Enter phone with:"
echo ""
echo "adb shell"
echo "su"
echo "mount /sdcard"
echo "flash_image boot /sdcard/patchedBoot.img"
echo ""
echo "********************************************************"
echo ""








